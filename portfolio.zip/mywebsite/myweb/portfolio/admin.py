from django.contrib import admin
from .models import blog,employer,mynotes,tag,Note,notes_name,subject_name,individual_note

# Register your models here.
@admin.register(blog)
class QuillPostAdmin(admin.ModelAdmin):
    pass
admin.site.register(employer)


admin.site.register(mynotes)
admin.site.register(tag)
admin.site.register(Note)
admin.site.register(notes_name)
admin.site.register(subject_name)
admin.site.register(individual_note)
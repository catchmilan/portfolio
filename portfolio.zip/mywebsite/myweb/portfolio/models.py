from django.db import models
from django_quill.fields import QuillField
from ckeditor.fields import RichTextField
# Create your models here.

class notes_name(models.Model):
    nn_title=models.CharField(max_length=200)

    def __str__(self):
        return self.nn_title

class subject_name(models.Model):
    sn_nn_title=models.ForeignKey('notes_name', on_delete=models.CASCADE, related_name='subjectname')
    sn_title=models.CharField(max_length=200,blank=True,null=True)

    def __str__(self):
        return self.sn_title

class individual_note(models.Model):
    #in_nn_title = models.ForeignKey('notes_name',on_delete=models.CASCADE,blank=True,null=True,related_name='individualnotetitle')
    in_sn_sn_title= models.ForeignKey('subject_name',on_delete=models.CASCADE, blank=True, null= True, related_name='individualsubjnote')
    in_title=models.CharField(max_length=200)
    in_content=RichTextField()
    in_created_at = models.DateTimeField(auto_now_add=True)
    in_updated_at = models.DateTimeField(auto_now=True)
    in_tags = models.ManyToManyField('tag',related_name='each_materials')
    def __str__(self):
        return self.in_title

class blog(models.Model):
    title=models.CharField(max_length=200)
    description=RichTextField()
    tags = models.ManyToManyField('tag',related_name='blog_tag')
    def __str__(self):
        return self.title

class employer(models.Model):
    office_name=models.CharField(max_length=200)
    title=models.CharField(max_length=200)
    working_from=models.DateField()
    working_to=models.DateField(null=True,blank=True)
    basic_responsibility=models.TextField()

    def __str__(self):
        return self.office_name

class mynotes(models.Model):
    title=models.CharField(max_length=200)
    content=RichTextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    tags = models.ManyToManyField('tag',related_name='study_materials')
    def __str__(self):
        return self.title


class tag(models.Model):
    name=models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.name


class Note(models.Model):
    title = models.CharField(max_length=200)
    content = RichTextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

class math(models.Model):
    title=models.CharField(max_length=200)
    content=RichTextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    tags = models.ManyToManyField('tag',related_name='math_materials')
    def __str__(self):
        return self.title

class mysql(models.Model):
    title=models.CharField(max_length=200)
    content=RichTextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    tags = models.ManyToManyField('tag',related_name='mysql_materials')
    def __str__(self):
        return self.title


class linux(models.Model):
    title=models.CharField(max_length=200)
    content=RichTextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    tags = models.ManyToManyField('tag',related_name='linux_materials')
    def __str__(self):
        return self.title

class other(models.Model):
    title=models.CharField(max_length=200)
    content=RichTextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    tags = models.ManyToManyField('tag',related_name='other_materials')
    def __str__(self):
        return self.title
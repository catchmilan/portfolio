from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='index'),
    path('blog/', views.blogview, name='blog'),
    path('notes/', views.notes, name='notes'),
    path('cv/',views.cv,name='cv'),
    path('search_notes/',views.search_notes, name='search_notes'),
    path('note/<int:id>',views.eachnote,name='eachnote'),
    path('eachblog/<int:id>',views.eachblog,name='eachblog'),
    path('contact/',views.contact,name='contact'),
    path('search_blog/',views.search_blog, name='search_blog'),
    path('notes_by_tag/<int:tag_id>/', views.notes_by_tag, name='notes_by_tag'),
    path('math/',views.maths,name='math'),
    path('mysql/',views.mysql,name='mysql'),
    path('linux/',views.linux,name='linux'),
    path('other/',views.other,name='other'),
    path('subject/<int:id>/',views.subject,name='subject'),
    path('indv_note/<int:id>',views.indv_note,name='indv_note'),
    path('viewnote/<int:id>',views.viewnote,name='viewnote')
]
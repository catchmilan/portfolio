from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import blog,employer,mynotes,tag,Note,notes_name,subject_name,individual_note
# Create your views here.

def viewnote(request,id):
    individual_notes = individual_note.objects.get(id=id)
    print(individual_notes.in_sn_sn_title.sn_nn_title_id)
    subject_name = individual_notes.in_sn_sn_title
    notes_name=subject_name.sn_nn_title
    subject_title=subject_name.sn_title
    notes_title=notes_name.nn_title
    print(subject_name)
    print(notes_name)
    context={'notes_name':notes_name,'subject_name':subject_name,'individual_notes':individual_notes}
    return render(request,'portfolio/viewnote.html',context)


def indv_note(request,id):
    subject = subject_name.objects.get(id=id)
    individual_notes = individual_note.objects.filter(in_sn_sn_title=subject)
    context={'subject':subject, 'individual_notes':individual_notes}
    return render(request,'portfolio/individual_note.html',context)

def subject(request,id):
    note = notes_name.objects.get(id=id)
    subjects = subject_name.objects.filter(sn_nn_title=note)
    
    checksubject=individual_note.objects.get(id=id)
    print(checksubject)
    subject_name2=checksubject.in_sn_sn_title
    notes_name2=subject_name2.sn_nn_title
    subject_title=subject_name.sn_title
    notes_title=notes_name2.nn_title
    print(subject_title)
    print(notes_title)
    context={'note':note, 'subjects':subjects}
    return render(request,'portfolio/subject.html',context)

def notes(request):
    notes = mynotes.objects.all()
    an_notes = notes_name.objects.all()
    context= {'notes':notes,'an_notes':an_notes}
    return render(request, 'portfolio/notes.html',context)


def contact(request):
    return render(request,'portfolio/contact.html')

def eachblog(request, id):
    blogitem= get_object_or_404(blog, id=id)
    context={'blogitem':blogitem}
    return render (request, 'portfolio/eachblog.html', context)

def eachnote(request, id):
    note = get_object_or_404(individual_note,id=id)
    context={'note':note}
    return render (request, 'portfolio/eachnote.html', context)

def search_blog(request):
    query=request.GET.get('query','')
    blogs= blog.objects.filter(title__icontains=query)
    context= {'blogs':blogs}
    return render(request, 'portfolio/blogssearch.html',context)

def search_notes(request):
    query=request.GET.get('query','')
    notes= individual_note.objects.filter(in_title__icontains=query)
    context= {'notes':notes}
    return render(request, 'portfolio/notessearch.html',context)

def home(request):
    return render(request, 'portfolio/index.html')

def blogview(request):
    blogs = blog.objects.all()
    context= {'blogs':blogs}
    print(blogs)
    return render(request, 'portfolio/blog.html', context)


def cv(request):
    employers=employer.objects.all()
    context={'employers':employers}
    return render(request, 'portfolio/cv.html',context)



def notes_by_tag(request, tag_id):
    # Get the tag object based on the tag_id
    #note = get_object_or_404(mynotes,id=id)
    selected_tag = tag.objects.get(pk=tag_id)
    print(selected_tag)
    # Get all notes related to the selected tag
    notes = individual_note.objects.filter(in_tags=selected_tag)
    print(notes)
    context = {
        'tag':selected_tag,
        'notes': notes,
    }

    return render(request, 'portfolio/notes_by_tag.html', context)

def maths(request):
    math_query=Note.objects.all()
    context={'math_query':math_query}
    return render(request,'portfolio/maths.html',context)

def mysql(request):
    pass

def linux(request):
    pass

def other(request):
    pass